# Alfatih_trial > 2024-03-08 2:16pm
https://universe.roboflow.com/trinadia/alfatih_trial

Provided by a Roboflow user
License: MIT

